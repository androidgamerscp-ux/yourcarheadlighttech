package com.slotmonitoring.app

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnQuickScan = findViewById<Button>(R.id.btnQuickScan)
        val tvTotalGames = findViewById<TextView>(R.id.tvTotalGames)
        val tvTotalResults = findViewById<TextView>(R.id.tvTotalResults)

        btnQuickScan.setOnClickListener {
            Toast.makeText(this, "Quick Scan Session Started & Result Recorded!", Toast.LENGTH_SHORT).show()
            val currentResults = tvTotalResults.text.toString().toIntOrNull() ?: 12
            tvTotalResults.text = (currentResults + 1).toString()
        }

        findViewById<Button>(R.id.btnNavCatalog).setOnClickListener {
            Toast.makeText(this, "Opening Slot Games Catalog...", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnNavManual).setOnClickListener {
            Toast.makeText(this, "Opening Manual Entry...", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnNavHistory).setOnClickListener {
            Toast.makeText(this, "Opening Historical Database...", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnNavAnalytics).setOnClickListener {
            Toast.makeText(this, "Opening Analytics & Statistics...", Toast.LENGTH_SHORT).show()
        }
    }
}
